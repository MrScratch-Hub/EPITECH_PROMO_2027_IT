/*
** EPITECH PROJECT, 2022
** B-MUL-200-PAR-2-2-mypaint-loup.marquez
** File description:
** my_paint.h
*/

#ifndef PAINT_H_
    #define PAINT_H_
    #include <SFML/Graphics.h>
    #include <SFML/Window.h>
    #include <stdlib.h>
    #define W 820
    #define H 600

typedef struct {
    sfRectangleShape *buttons[5];
    sfColor selected_color;
    sfEvent event;
    sfVector2f last_position;
    sfBool is_mouse_pressed;
    sfVector2f button_size;
    int button_margin;
} GameData;

void create_button(GameData *data, int button_num);
void game_loop(sfRenderWindow *window, sfTexture *canvas_texture,
sfSprite *canvas_sprite, GameData *data);

#endif
