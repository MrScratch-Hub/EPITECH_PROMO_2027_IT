/*
** EPITECH PROJECT, 2022
** B-MUL-200-PAR-2-2-mypaint-loup.marquez
** File description:
** main.c
*/

#include "../include/my_paint.h"

void clean_up(sfRenderWindow *window, sfTexture *canvas_texture,
sfSprite *canvas_sprite)
{
    sfSprite_destroy(canvas_sprite);
    sfTexture_destroy(canvas_texture);
    sfRenderWindow_destroy(window);
}

int main(void)
{
    sfVideoMode mode = {W, H, 32};
    sfImage *background = sfImage_createFromColor(W, H, sfWhite);
    sfRenderWindow *window = sfRenderWindow_create(mode, "Paint App",
    sfResize | sfClose, NULL);
    sfTexture *canvas_texture = sfTexture_create(W, H);
    sfSprite *canvas_sprite = sfSprite_create();
    sfSprite_setTexture(canvas_sprite, canvas_texture, sfTrue);
    sfTexture_updateFromImage(canvas_texture, background, 0, 0);
    sfImage_destroy(background);
    GameData *data = malloc(sizeof(GameData));

    data->selected_color = sfRed;
    data->last_position = (sfVector2f){0, 0};
    data->is_mouse_pressed = sfFalse;
    data->button_size = (sfVector2f){50, 50};
    data->button_margin = 10;
    game_loop(window, canvas_texture, canvas_sprite, data);
    clean_up(window, canvas_texture, canvas_sprite);
    return EXIT_SUCCESS;
}
