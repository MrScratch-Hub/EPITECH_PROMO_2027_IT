/*
** EPITECH PROJECT, 2023
** B-MUL-200-PAR-2-2-mypaint-loup.marquez
** File description:
** game
*/

#include "../include/my_paint.h"

void create_button(GameData *data, int button_num)
{
    for (int i = 0; i < button_num; ++i) {
        sfRectangleShape *button = sfRectangleShape_create();
        sfVector2f button_pos = {W - data->button_size.x - data->button_margin,
        H - (i + 1) * data->button_size.y - (i + 1) * data->button_margin};
        sfRectangleShape_setSize(button, data->button_size);
        switch (i) {
        case 0: sfRectangleShape_setFillColor(button, sfRed); break;
        case 1: sfRectangleShape_setFillColor(button, sfBlue); break;
        case 2: sfRectangleShape_setFillColor(button, sfGreen); break;
        case 3: sfRectangleShape_setFillColor(button, sfBlack); break;
        case 4:
            sfRectangleShape_setFillColor(button, sfWhite);
            sfRectangleShape_setOutlineColor(button, sfBlack);
            sfRectangleShape_setOutlineThickness(button, 2); break;
        }
        sfRectangleShape_setPosition(button, button_pos);
        data->buttons[i] = button;
    }
}

void for_loop(GameData *data, sfRenderWindow *window,
sfTexture *canvas_texture, sfSprite *canvas_sprite)
{
    for (int i = 0; i < 5; ++i) {
        sfFloatRect rect = sfRectangleShape_getGlobalBounds(data->buttons[i]);
        if (sfFloatRect_contains(&rect, data->event.mouseButton.x,
        data->event.mouseButton.y)) {
            switch (i) {
            case 0: data->selected_color = sfRed; break;
            case 1: data->selected_color = sfBlue; break;
            case 2: data->selected_color = sfGreen; break;
            case 3: data->selected_color = sfBlack; break;
            case 4: data->selected_color = sfWhite; break;
            } break;
        }
    }
}

void if_cond(GameData *data, sfRenderWindow *window, sfTexture *canvas_texture,
sfSprite *canvas_sprite)
{
    if (data->is_mouse_pressed) {
        sfVertexArray *line = sfVertexArray_create();
        sfVertex vertex1 = {data->last_position,
                            data->selected_color};
        sfVertex vertex2 = {{data->event.mouseMove.x, data->event.mouseMove.y},
                            data->selected_color};
        sfVertexArray_append(line, vertex1);
        sfVertexArray_append(line, vertex2);
        sfVertexArray_setPrimitiveType(line, sfLines);
        sfRenderWindow_drawVertexArray(window, line, NULL);
        sfTexture_updateFromRenderWindow(canvas_texture, window, 0, 0);
        data->last_position = vertex2.position;
        sfVertexArray_destroy(line);
    }
}

void switch_cond(GameData *data, sfRenderWindow *window,
sfTexture *canvas_texture, sfSprite *canvas_sprite)
{
    switch (data->event.type) {
    case sfEvtClosed:
        sfRenderWindow_close(window); break;
    case sfEvtMouseButtonPressed:
        data->is_mouse_pressed = sfTrue;
        data->last_position.x = data->event.mouseButton.x;
        data->last_position.y = data->event.mouseButton.y; break;
    case sfEvtMouseButtonReleased:
        data->is_mouse_pressed = sfFalse;
        for_loop(data, window, canvas_texture, canvas_sprite); break;
    case sfEvtMouseMoved:
        if_cond(data, window, canvas_texture, canvas_sprite); break;
    default: break;
    }
}

void game_loop(sfRenderWindow *window, sfTexture *canvas_texture,
sfSprite *canvas_sprite, GameData *data)
{
    create_button(data, 5);
    while (sfRenderWindow_isOpen(window)) {
        while (sfRenderWindow_pollEvent(window, &data->event)) {
            switch_cond(data, window, canvas_texture, canvas_sprite);
        }
        sfRenderWindow_clear(window, sfWhite);
        sfRenderWindow_drawSprite(window, canvas_sprite, NULL);
        for (int i = 0; i < 5; ++i) {
            sfRenderWindow_drawRectangleShape(window, data->buttons[i], NULL);
        }
        sfRenderWindow_display(window);
    }
}
