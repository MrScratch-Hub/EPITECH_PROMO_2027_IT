/*
** EPITECH PROJECT, 2022
** my_hunter
** File description:
** character
*/

#include "../lib/my/my.h"

sfVector2f step_offset(sfVector2f point_a, sfVector2f point_b)
{
    int dx = point_b.x - point_a.x,
    dy = point_b.y - point_a.y;
    int steps = (abs(dx) > abs(dy)) ? abs(dx) : abs(dy);
    sfVector2f offset;

    offset.x = dx / (float)steps;
    offset.y = dy / (float)steps;
    return offset;
}

coord_t *path_create(sfVector2f beg, sfVector2f end, int speed, int w_width)
{
    coord_t *path = malloc(sizeof(*path));
    sfVector2f alt_pos = beg;

    alt_pos.x += (beg.x < end.x) ? (int)w_width : -((int)w_width);
    path->pos = beg;
    path->end = end;
    if (fabs(end.x - beg.x) <= fabs(end.x - alt_pos.x)) {
        path->step = step_offset(beg, end);
    } else
        path->step = step_offset(alt_pos, end);
    path->step.x *= speed;
    path->step.y *= speed;
    return (path);
}

tower_t *tower_create(sfVector2f pos, sfTexture *texture, int radius)
{
    tower_t *tower = malloc(sizeof(*tower));
    sfVector2f circle_pos = {pos.x + 20 - radius, pos.y + 20 - radius};

    tower->pos = pos;
    tower->radius = radius;
    tower->sprite = sfSprite_create();
    tower->control_area = sfCircleShape_create();
    sfSprite_setTexture(tower->sprite, texture, sfTrue);
    sfSprite_setPosition(tower->sprite, tower->pos);
    sfCircleShape_setRadius(tower->control_area, radius);
    sfCircleShape_setFillColor(tower->control_area, sfTransparent);
    sfCircleShape_setOutlineColor(tower->control_area, sfBlue);
    sfCircleShape_setOutlineThickness(tower->control_area, 5);
    sfCircleShape_setPosition(tower->control_area, circle_pos);
    return tower;
}

sfVector2f random_tower_pos(tower_t **towers)
{
    int nb_towers = 0;
    sfVector2f random_tower_pos;

    for (nb_towers = 0; towers[nb_towers]; nb_towers++);
    random_tower_pos = (towers[rand() % nb_towers])->pos;
    return (random_tower_pos);
}

coord_t *get_random_path(tower_t **towers, int w_width)
{
    sfVector2f beg;
    sfVector2f end;
    int speed = rand() % (6 + 1 - 3) + 3;

    beg = random_tower_pos(towers);
    end = random_tower_pos(towers);
    while (beg.x == end.x && beg.y == end.y)
        end = random_tower_pos(towers);
    return (path_create(beg, end, speed, w_width));
}

sfVector2f *get_rotated_corners(sfFloatRect hitbox, float angle)
{
    sfVector2f center = {hitbox.left + hitbox.width / 2.0, hitbox.top + hitbox.height / 2.0};
    sfVector2f *corners = malloc(sizeof(sfVector2f) * 4);
	sfVector2f rotated_point;
    if (!corners) {
        return (NULL);
    }
    corners[0] = (sfVector2f){hitbox.left, hitbox.top};
    corners[1] = (sfVector2f){hitbox.left + hitbox.width, hitbox.top};
    corners[2] = (sfVector2f){hitbox.left, hitbox.top + hitbox.height};
    corners[3] = (sfVector2f){hitbox.left + hitbox.width,
                              hitbox.top + hitbox.height};
    if (!corners) {
        return (NULL);
    }
    for (unsigned int i = 0; i < 4; i++) {
    angle = angle * (M_PI / 180);
    rotated_point.x = cos(angle) * (corners[i].x - center.x) - sin(angle) * (corners[i].y - center.y) + center.x;
    rotated_point.y = sin(angle) * (corners[i].x - center.x) + cos(angle) * (corners[i].y - center.y) + center.y;
    corners[i] = rotated_point;
	}
    return (corners);
}

sfFloatRect get_bounding_box_of_rotated(sfFloatRect const hitbox, float angle)
{
    sfVector2f *rotated_corners = get_rotated_corners(hitbox, angle);
    float min_x = rotated_corners[0].x;
    float max_x = rotated_corners[0].x;
    float min_y = rotated_corners[0].y;
    float max_y = rotated_corners[0].y;

    for (unsigned int i = 1; i < 4; i++)
    {
        if (rotated_corners[i].x < min_x)
            min_x = rotated_corners[i].x;
        if (rotated_corners[i].x > max_x)
            max_x = rotated_corners[i].x;
        if (rotated_corners[i].y < min_y)
            min_y = rotated_corners[i].y;
        if (rotated_corners[i].y > max_y)
            max_y = rotated_corners[i].y;
    }
    free(rotated_corners);
    return ((sfFloatRect){min_x, min_y, max_x - min_x, max_y - min_y});
}

void plane_move(plane_t *plane, sfVector2f const offset, int w_width)
{
    sfVector2f offset_out = {(float)w_width, 0.0};

    plane->path->pos.x  += offset.x;
    plane->path->pos.y  += offset.y;
    plane->hitbox.left  += offset.x;
    plane->hitbox.top   += offset.y;
    sfSprite_move(plane->sprite, offset);
    sfRectangleShape_setPosition(plane->outline, (sfVector2f)
                                {plane->hitbox.left, plane->hitbox.top});
    if (plane->path->pos.x < 0 || plane->path->pos.x > w_width) {
        if (plane->path->pos.x > w_width) {
        offset_out.x = -offset_out.x;
        }
        plane_move(plane, offset_out, w_width);
    }
}

float angle_from_coordinate(sfVector2f point_a, sfVector2f point_b)
{
    float dx = point_b.x - point_a.x;
    float dy = point_b.y - point_a.y;
    float radians = atan2f(dx, dy);

    if (radians < 0.0)
        radians = fabs(radians);
    else
        radians = 2 * M_PI - radians;
    return (180.0 / M_PI * radians);
}

float plane_angle_by_path(plane_t *plane, int w_width)
{
    sfVector2f plane_beg = plane->path->pos;
    float x_diff = plane->path->end.x - plane->path->pos.x;

    if ((plane->path->step.x < 0) != (x_diff < 0))
    {
        if ((plane->path->step.x < 0) && (x_diff > 0))
            plane_beg.x += w_width;
        else
            plane_beg.x -= w_width;
    }
    return (angle_from_coordinate(plane->path->end, plane_beg));
}

plane_t *plane_init(plane_t *plane, coord_t *path, int delay, int w_width)
{
    plane->delay = delay;
    plane->path = path;
    sfSprite_setPosition(plane->sprite, plane->path->pos);
    sfSprite_move(plane->sprite, (sfVector2f){10, 10});
    sfFloatRect hitbox = {plane->path->pos.x, plane->path->pos.y, 20, 20};
    sfSprite_setRotation(plane->sprite, 0.0);
    plane->angle = plane_angle_by_path(plane, w_width);
    sfSprite_rotate(plane->sprite, plane->angle);
    plane->hitbox = hitbox;
    plane->hitbox = get_bounding_box_of_rotated(plane->hitbox, plane->angle);
    sfRectangleShape_setPosition(plane->outline, (sfVector2f){plane->hitbox.left, plane->hitbox.top});
    sfRectangleShape_setSize(plane->outline, (sfVector2f){plane->hitbox.width, plane->hitbox.height});
    return plane;
}

void plane_loop(sf_data sf_info, plane_t *plane, int c_time)
{
    coord_t *new_path = NULL;
    int new_delay = 0;
    float x_diff = fabs(plane->path->end.x - plane->path->pos.x),
    y_diff = fabs(plane->path->end.y - plane->path->pos.y);

    if (plane->delay > c_time) {
        return;
    }
    if (sf_info.state->show_sprites) {
        sfRenderWindow_drawSprite(sf_info.window, plane->sprite, NULL);
    }
    if (sf_info.state->show_hitbox) {
        sfRenderWindow_drawRectangleShape(sf_info.window, plane->outline, NULL);
    }
    plane_move(plane, plane->path->step, 1920);
    if (x_diff <= 10.0 && y_diff <= 10.0) {
        new_path = get_random_path(sf_info.towers, 1920);
        new_delay = c_time + rand() % 20;
        plane = plane_init(plane, new_path, new_delay, 1920);
    }
}
