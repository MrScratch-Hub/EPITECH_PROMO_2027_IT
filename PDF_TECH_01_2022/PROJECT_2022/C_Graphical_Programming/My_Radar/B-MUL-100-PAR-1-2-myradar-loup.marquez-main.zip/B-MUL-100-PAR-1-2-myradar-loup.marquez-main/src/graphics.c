/*
** EPITECH PROJECT, 2022
** B-MUL-100-PAR-1-2-myhunter-loup.marquez
** File description:
** graphics
*/

#include "../lib/my/my.h"

int rand_nb(void)
{
    int rand_nb = rand() % 400 + 10;
}

void poll_event(sfRenderWindow *window, sfVector2f *position)
{
    sf_data *sf_info = malloc(sizeof(sf_data));
    sfEvent event;
    while (sfRenderWindow_pollEvent(window, &event))
    {
        if (event.type == sfEvtClosed)
        {
            sfRenderWindow_close(window);
        }
        if (event.key.code == sfKeyEscape) {
                sfRenderWindow_close(window);
        }
        if (event.type == sfEvtKeyReleased) {
                switch (event.key.code) {
                case sfKeyL:
                    sf_info->state->show_hitbox = (sf_info->state->show_hitbox) ? sfFalse : sfTrue;
                    break;
                case sfKeyS:
                    sf_info->state->show_sprites = (sf_info->state->show_sprites) ? sfFalse : sfTrue;
                    break;
                default:
                    break;
                }
            }
    }
}

int game_main(char *path)
{
    sf_data sf_info;
    sfIntRect rect;
    sfVector2f position;
    sfVideoMode mode = {1920, 1080, 32};
    sf_info.window = sfRenderWindow_create(mode, "My Radar",
                                           sfResize | sfClose, NULL);
    sf_info.texturebg = sfTexture_createFromFile("image/backgrounds/bg.jpg", NULL);
    sf_info.spritebg = sfSprite_create();
    sfClock *clock;
    clock = sfClock_create();
    while (sfRenderWindow_isOpen(sf_info.window))
    {
        sfRenderWindow_setFramerateLimit(sf_info.window, 30);
        poll_event(sf_info.window, &position);
        int c_time = sfTime_asSeconds(sfClock_getElapsedTime(clock));
        sfSprite_setTexture(sf_info.spritebg, sf_info.texturebg, sfTrue);
        sfRenderWindow_clear(sf_info.window, sfBlack);
        sfRenderWindow_drawSprite(sf_info.window, sf_info.spritebg, NULL);
        for (int i = 0; sf_info.towers[i]; i++) {
            if (sf_info.state->show_sprites){
                sfRenderWindow_drawSprite(sf_info.window, sf_info.towers[i]->sprite, NULL);
            }
            if (sf_info.state->show_hitbox) {
                sfRenderWindow_drawCircleShape(sf_info.window, sf_info.towers[i]->control_area, NULL);
            }
        }
        for (int i = 0; sf_info.planes[i]; i++) {
            plane_loop(sf_info, sf_info.planes[i], c_time);
        }
        sfRenderWindow_display(sf_info.window);
    }
}
