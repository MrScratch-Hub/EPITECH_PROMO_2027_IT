/*
** EPITECH PROJECT, 2022
** my_hunter
** File description:
** window_open
*/

#include "../lib/my/my.h"

int main(int ac, char **av)
{
    if (ac != 2)
    {
        my_printf("bad arguments : %d given but only 1 is required\n", (ac - 1));
        return 84;
    }
    if (av[1][0] == '-' && av[1][1] == 'h')
    {
        my_printf("USAGE\n");
        my_printf("./my_radar [OPTIONS] coord_to_script\n");
        my_printf("coord_to_script   The path to the script file.\n");
        my_printf("OPTIONS\n");
        my_printf("-h   print the usage and quit.\n");
        my_printf("USER INTERACTIONS\n");
        my_printf("'L' key   enable/disable hitboxes and areas.\n");
        my_printf("'S' key   enable/disable sprites.\n");
        return 0;
    }
    else
    {
        game_main(av[1]);
        return 0;
    }
    return 0;
}
