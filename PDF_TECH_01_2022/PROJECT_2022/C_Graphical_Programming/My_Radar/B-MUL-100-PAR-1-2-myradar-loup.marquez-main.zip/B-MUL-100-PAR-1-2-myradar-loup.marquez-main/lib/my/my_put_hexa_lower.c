/*
** EPITECH PROJECT, 2022
** my_put_hexa_lower.c
** File description:
** my put hexa lower
*/

#include "my.h"

unsigned int my_put_hexa_lower(unsigned int decimalnum)
{
    int i = 0;
    int remain = 0;
    char hexanum[100];

    while (decimalnum != 0) {
        remain = decimalnum % 16;
        if (remain < 10) {
            hexanum[i] = remain + 48;
        } else {
            hexanum[i] = remain + 87;
        }
        i++;
        decimalnum = decimalnum / 16;
    }
    i--;
    for (int j = i; j >= 0; j--) {
        my_putchar(hexanum[j]);
    }
    return 0;
}
