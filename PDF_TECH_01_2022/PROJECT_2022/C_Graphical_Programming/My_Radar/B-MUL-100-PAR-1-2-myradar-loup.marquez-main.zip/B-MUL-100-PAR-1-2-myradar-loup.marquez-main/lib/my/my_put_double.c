/*
** EPITECH PROJECT, 2022
** myprintf
** File description:
** double decimal
*/

#include "my.h"
#include <stdlib.h>

int my_power(int nb, int p)
{
    int res;
    if (p < 0) {
        return -1;
    } for (res = 1; p >= 1; --p) {
        res = res * nb;
        --p;
    }
    return res;
}

int my_put_double(double decimal, int precision )
{
    long buff = (long)decimal;
    int accuracy = precision * 2;
    int power_of = (int) my_power(10, accuracy);

    if (precision < 0) {
        return -1;
    } else {
    my_put_nbr(buff);
    decimal = ((decimal - buff) * power_of );
    buff = labs((long)decimal);
    my_putchar('.');
    my_put_nbr(buff);
    }
    return 0;
}
