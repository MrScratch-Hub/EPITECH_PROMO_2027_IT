/*
** EPITECH PROJECT, 2022
** mini_printf.c
** File description:
** incomplet printf
*/

#include "my.h"
#include <stdarg.h>

int my_printf(const char *format, ...)
{
    va_list arg;
    va_start(arg, format);
    for (int i = 0; format[i] != '\0'; i++) {
        switch (format[i]) {
        case '%': flags_index(format, i, arg); i++;
            break;
        default: my_putchar(format[i]);
            break;
        }
    }
    va_end(arg);
    return 0;
}
