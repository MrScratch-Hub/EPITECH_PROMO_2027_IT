/*
** EPITECH PROJECT, 2022
** myprintf
** File description:
** second index for printf
*/

#include "my.h"

void flags_index_second(const char *format, int i, va_list arg)
{
    switch (format[i + 1]) {
    case 'u': my_put_unsigned_nbr(va_arg(arg, unsigned int)); i++;
        break;
    case 'f': my_put_double(va_arg(arg, double), va_arg(arg, int)); i++;
        break;
    case 'o': my_decimal_to_octal(va_arg(arg, int)); i++;
        break;
    case 'x': my_put_hexa_lower(va_arg(arg, unsigned int)); i++;
        break;
    case 'X': my_put_hexa(va_arg(arg, unsigned int)); i++;
        break;
    case 'b': my_put_binary(va_arg(arg,unsigned int)); i++;
        break;
    default: my_putstr("84"); i++;
        break;
    }
}
