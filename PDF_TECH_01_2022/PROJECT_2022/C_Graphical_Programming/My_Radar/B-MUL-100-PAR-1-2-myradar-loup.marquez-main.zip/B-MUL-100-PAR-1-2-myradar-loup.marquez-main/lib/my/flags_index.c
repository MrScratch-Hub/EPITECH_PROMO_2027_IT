/*
** EPITECH PROJECT, 2022
** index_printf.c
** File description:
** index for printf
*/

#include "my.h"

void flags_index(const char *format, int i, va_list arg)
{
    switch (format[i + 1]) {
    case 'd':
    case 'i': my_put_nbr(va_arg(arg, int)); i++;
        break;
    case 'c': my_putchar(va_arg(arg, int)); i++;
        break;
    case 's': my_putstr(va_arg(arg, char *)); i++;
        break;
    case '%': my_putchar('%'); i++;
        break;
    default: flags_index_second(format, i, arg); i++;
        break;
    }
}
