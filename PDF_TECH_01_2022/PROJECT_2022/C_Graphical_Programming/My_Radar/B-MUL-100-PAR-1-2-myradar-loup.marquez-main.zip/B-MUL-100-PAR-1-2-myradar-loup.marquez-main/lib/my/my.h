/*
** EPITECH PROJECT, 2022
** my.h
** File description:
** my includes
*/

#ifndef MY_H_
    #define MY_H_

    #include <SFML/Graphics.h>
    #include <SFML/System.h>
    #include <SFML/Audio.h>
    #include <time.h>
    #include <stdlib.h>
    #include <stdarg.h>
    #include <math.h>

typedef sfBool Bool;
typedef sfTexture texture_t;

typedef struct coord_s
{
    sfVector2f pos;
    sfVector2f end;
    sfVector2f step;
} coord_t;

typedef struct plane_s
{
    coord_t *path;
    unsigned int delay;
    float angle;
    sfFloatRect hitbox;
    sfSprite *sprite;
    sfRectangleShape *outline;
} plane_t;

typedef struct base_states_s
{
    Bool show_hitbox;
    Bool show_sprites;
    Bool is_paused;
} base_states_t;
typedef base_states_t states_t;

typedef struct base_textures_s
{
    texture_t *base_bg;
    texture_t *plane;
    texture_t *tower;
} base_textures_t;
typedef base_textures_t textures_t;

typedef struct tower_s
{
    sfVector2f pos;
    unsigned int radius;
    sfSprite *sprite;
    sfCircleShape *control_area;
} tower_t;

typedef struct sf_info{
    sfRenderWindow *window;
    sfTexture *texturebg;
    sfSprite *spritebg;
    plane_t **planes;
    tower_t **towers;
    textures_t *textures;
    states_t *state;
    sfTime time;
} sf_data;

sfVector2f step_offset(sfVector2f point_a, sfVector2f point_b);
coord_t *path_create(sfVector2f beg, sfVector2f end, int speed, int w_width);
tower_t *tower_create(sfVector2f pos, sfTexture *texture, int radius);
sfVector2f random_tower_pos(tower_t **towers);
coord_t *get_random_path(tower_t **towers, int w_width);
sfVector2f *get_rotated_corners(sfFloatRect hitbox, float angle);
sfFloatRect get_bounding_box_of_rotated(sfFloatRect const hitbox, float angle);
void plane_move(plane_t *plane, sfVector2f const offset, int w_width);
float plane_angle_by_path(plane_t *plane, int w_width);
float plane_angle_by_path(plane_t *plane, int w_width);
plane_t *plane_init(plane_t *plane, coord_t *path, int delay, int w_width);
int game_main(char *path);
void plane_loop(sf_data sf_info, plane_t *plane, int c_time);
unsigned int my_put_unsigned_nbr(unsigned int nb);
int my_put_double(double decimal, int precision );
unsigned int my_decimal_to_octal(unsigned int decimalnum);
unsigned int my_put_hexa(unsigned int decimalnum);
unsigned int my_put_hexa_lower(unsigned int decimalnum);
unsigned int my_put_binary(unsigned int decimalnum);
void flags_index(const char *format, int i, va_list arg);
void flags_index_second(const char *format, int i, va_list arg);
int my_printf(const char *format, ...);
void my_putchar(char c);
int my_isneg(int nb);
int my_put_nbr(int nb);
int my_putstr(char const *str);
int my_strlen(char const *str);
char *my_strcpy(char *dest, char const *src);
char *my_strncpy(char *dest, char const *src, int n);
char *my_strcat(char *dest, char const *src);
char *my_revstr(char *str);
char *my_strncat(char *dest, char const *src, int nb);

#endif /* MY_H_ */
