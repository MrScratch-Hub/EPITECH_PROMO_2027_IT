/*
** EPITECH PROJECT, 2022
** my.h
** File description:
** my includes
*/

#ifndef MY_H_
    #define MY_H_

    #include <SFML/Graphics.h>
    #include <SFML/System.h>
    #include <SFML/Audio.h>
    #include <time.h>
    #include <stdlib.h>
    #include <stdarg.h>

typedef struct data {
int score;
int life;
int info;
} game_data;

typedef struct sf_info{
    sfRenderWindow *window;
    sfTexture *texturebg;
    sfSprite *spritebg;
    sfTexture *texture_char;
    sfSprite *sprite_char;
    sfTime time;
} sf_data;

int game_main(void);
void mouse_event(sfMouseButtonEvent event, sfVector2f *position,
sfRenderWindow *window, game_data *data);
int rand_nb(void);
game_data game_info(void);
int move_pos(sfVector2f *position, sfIntRect *rect, int i);
void move_rect(sfIntRect *rect, int offset, int max_value);
unsigned int my_put_unsigned_nbr(unsigned int nb);
int my_put_double(double decimal, int precision );
unsigned int my_decimal_to_octal(unsigned int decimalnum);
unsigned int my_put_hexa(unsigned int decimalnum);
unsigned int my_put_hexa_lower(unsigned int decimalnum);
unsigned int my_put_binary(unsigned int decimalnum);
void flags_index(const char *format, int i, va_list arg);
void flags_index_second(const char *format, int i, va_list arg);
int my_printf(const char *format, ...);
void my_putchar(char c);
int my_isneg(int nb);
int my_put_nbr(int nb);
int my_putstr(char const *str);
int my_strlen(char const *str);
char *my_strcpy(char *dest, char const *src);
char *my_strncpy(char *dest, char const *src, int n);
char *my_strcat(char *dest, char const *src);
char *my_revstr(char *str);
char *my_strncat(char *dest, char const *src, int nb);

#endif /* MY_H_ */
