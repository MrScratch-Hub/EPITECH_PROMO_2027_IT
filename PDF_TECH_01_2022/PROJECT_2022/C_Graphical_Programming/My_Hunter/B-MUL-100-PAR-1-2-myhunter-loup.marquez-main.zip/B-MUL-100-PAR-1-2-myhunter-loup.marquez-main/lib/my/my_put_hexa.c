/*
** EPITECH PROJECT, 2022
** my_put_hexa.c
** File description:
** decimal to hexa
*/

#include "my.h"

unsigned int my_put_hexa(unsigned int decimalnum)
{
    int i = 0;
    int remain = 0;
    char hexanum[100];

    while (decimalnum != 0) {
        remain = decimalnum % 16;
        if (remain < 10) {
            hexanum[i] = remain + 48;
        } else {
            hexanum[i] = remain + 55;
        }
        i++;
        decimalnum = decimalnum / 16;
    }
    i--;
    for (int j = i; j >= 0; j--) {
        my_putchar(hexanum[j]);
    }
    return 0;
}
