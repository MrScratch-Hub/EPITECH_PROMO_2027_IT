/*
** EPITECH PROJECT, 2022
** B-MUL-100-PAR-1-2-myhunter-loup.marquez
** File description:
** graphics
*/

#include "../lib/my/my.h"

int rand_nb(void)
{
    int rand_nb = rand() % 400 + 10;
}

void poll_event(sfRenderWindow *window, sfVector2f *position, game_data *data)
{
    sfEvent event;
    while (sfRenderWindow_pollEvent(window, &event)) {
        if (event.type == sfEvtClosed) {
            sfRenderWindow_close(window);
        }
        if (event.type == sfEvtMouseButtonPressed) {
            mouse_event(event.mouseButton, position,
            window, data);
        }
    }
}

void game_main3(sf_data sf_info, sfVector2f position,
sfIntRect rect)
{
    sfSprite_setTexture(sf_info.spritebg, sf_info.texturebg,
                        sfTrue);
    sfSprite_setTexture(sf_info.sprite_char, sf_info.texture_char,
                        sfTrue);
    sfSprite_setTextureRect(sf_info.sprite_char, rect);
    sfSprite_setPosition(sf_info.sprite_char, position);
    sfRenderWindow_clear(sf_info.window, sfBlack);
    sfRenderWindow_drawSprite(sf_info.window, sf_info.spritebg,
    NULL);
    sfRenderWindow_drawSprite(sf_info.window, sf_info.sprite_char,
    NULL);
    sfRenderWindow_display(sf_info.window);
}

void game_main2(sf_data sf_info, sfVector2f position,
sfIntRect rect, game_data data)
{
    sfClock *clock;
    float seconds;
    sf_info.sprite_char = sfSprite_create();
    clock = sfClock_create();
    while (sfRenderWindow_isOpen(sf_info.window)) {
        sf_info.time = sfClock_getElapsedTime(clock);
        seconds = sf_info.time.microseconds / 100000.0;
        if (seconds > 1) {
            move_rect(&rect, 110, 330);
            sfClock_restart(clock);
        }
        data.info = move_pos(&position, &rect, data.info);
        sfRenderWindow_setFramerateLimit(sf_info.window, 60);
        poll_event(sf_info.window, &position, &data);
        game_main3(sf_info, position, rect);
    }
}

int game_main(void)
{
    sf_data sf_info;
    game_data data = game_info();
    sfIntRect rect;
    sfVector2f position;
    sfVideoMode mode = { 800, 600, 59};
    rect.top = 0;
    rect.left = 0;
    rect.width = 110;
    rect.height = 110;
    int rand = rand_nb();
    position.x = -10;
    position.y = rand;
    sf_info.window = sfRenderWindow_create(mode, "My Hunter",
    sfResize | sfClose, NULL);
    sf_info.texturebg = sfTexture_createFromFile("image/bg.jpg", NULL);
    sf_info.spritebg = sfSprite_create();
    sf_info.texture_char = sfTexture_createFromFile("image/sprite.png",
                                                    NULL);
    game_main2(sf_info, position, rect, data);
}
