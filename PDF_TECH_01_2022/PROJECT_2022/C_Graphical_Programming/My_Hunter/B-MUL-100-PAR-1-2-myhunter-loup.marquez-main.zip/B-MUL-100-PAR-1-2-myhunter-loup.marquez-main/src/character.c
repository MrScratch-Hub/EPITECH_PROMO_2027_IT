/*
** EPITECH PROJECT, 2022
** my_hunter
** File description:
** character
*/

#include "../lib/my/my.h"

int move_pos(sfVector2f *position, sfIntRect *rect, int i)
{
    position->x += i;
    if (position->x >= 1800) {
        rect->top = 110;
        i = -i;
    }
    if (position->x <= -200) {
        rect->top = 0;
        i = -i;
    }
    return (i);
}

void move_rect(sfIntRect *rect, int offset, int max_value)
{
    rect->left += offset;
    if (rect->left == max_value)
        rect->left = 0;
}

game_data game_info(void)
{
    game_data data;

    data.score = 0;
    data.life = 3;
    data.info = 4;
    return (data);
}

void mouse_cond(sfMouseButtonEvent event, sfVector2f *position,
sfRenderWindow *window, game_data *data)
{
    int rand = rand_nb();
    if (event.x >= position->x && event.x <= position->x + 110
                && event.y >= position->y && event.y <= position->y + 110) {
                position->x = -200;
                position->y = rand;
                data->score = data->score + 100;
                data->info += 1;
            } else if (data->life > 0) {
                data->life = data->life - 1;
            }
            if (data->life == 0) {
                my_printf("GAME OVER\n");
                sfRenderWindow_close(window);
            }
}

void mouse_event(sfMouseButtonEvent event, sfVector2f *position,
sfRenderWindow *window, game_data *data)
{
    if (event.type == sfEvtMouseButtonPressed) {
        if (event.button == sfMouseLeft) {
            mouse_cond(event, position, window, data);
        }
    }
}
