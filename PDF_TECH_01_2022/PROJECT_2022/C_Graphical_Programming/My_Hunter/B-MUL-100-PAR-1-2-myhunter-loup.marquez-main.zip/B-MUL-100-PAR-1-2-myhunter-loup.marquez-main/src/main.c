/*
** EPITECH PROJECT, 2022
** my_hunter
** File description:
** window_open
*/

#include "../lib/my/my.h"

int main(int ac, char **av)
{
    if (ac == 2 && av[1][0] == '-' && av[1][1] == 'h') {
        my_printf("The rules for the game are as follows:\n");
        my_printf("1. The Player is a hunter who shoots ducks.\n");
        my_printf("2. The Player can shoot the ducks ");
        my_printf("by using the mouse left clicks.\n");
        my_printf("3. If the Player miss the duck and");
        my_printf(" it's disappear into the right of the window,\n");
        my_printf("wait about 14 seconds it will comme back.\n");
        my_printf("4. The Player must have fun playing the game.\n");
        return 0;
    }
    if (ac == 1) {
        my_printf("GAME STARTING\n");
        game_main();
        return 0;
    } else {
        return 84;
    }
}
