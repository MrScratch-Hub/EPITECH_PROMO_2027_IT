/*
** EPITECH PROJECT, 2022
** 101pong.c
** File description:
** main file
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pong.h"

void display_angle(char **av)
{
    pong pong1 = {atof(av[1]), atof(av[2]), atof(av[3])};
    pong pong2 = {atof(av[4]), atof(av[5]), atof(av[6])};
    pong speed = {(pong2.x - pong1.x), (pong2.y - pong1.y),
    (pong2.z - pong1.z)};

    double pi = 3.14159265358979323846;
    double distance = sqrt(pow(speed.x, 2) + pow(speed.y, 2) + pow(speed.z, 2));
    double angle_rad = acos(speed.z / distance);
    double angle_deg = 180 * (angle_rad - (pi / 2)) / pi;
    double angle = fabs(angle_deg);

    printf("The incidence angle is:\n%.2f degrees\n", angle);
}

void display_vector(pong speed, pong after_time, int time)
{
    printf("The velocity vector of the ball is:\n(%.2f, %.2f, %.2f)\n",
    speed.x, speed.y, speed.z);
    printf("At time t + %d, ball coordinates will be:\n(%.2f, %.2f, %.2f)\n",
    time, after_time.x, after_time.y, after_time.z);
}

void paddle_conditions(char **av)
{
    int time = atoi(av[7]);
    pong pong1 = {atof(av[1]), atof(av[2]), atof(av[3])};
    pong pong2 = {atof(av[4]), atof(av[5]), atof(av[6])};
    pong speed = {(pong2.x - pong1.x), (pong2.y - pong1.y),
    (pong2.z - pong1.z)};
    pong after_time = {pong2.x + (speed.x * time),
    pong2.y + (speed.y * time), pong2.z + (speed.z * time)};

    if (speed.z != 0 && pong2.x != 0 && ((-pong2.z) / speed.z) >= 0) {
        display_vector(speed, after_time, time);
        display_angle(av);
    } else {
        display_vector(speed, after_time, time);
        printf("The ball won't reach the paddle.\n");
    }
}

void confirm_number(char *arr, int num)
{
    int idx = 0;
    while (arr[idx]) {
        if (num == 1 && ((arr[idx] >= 'A' && arr[idx] <= 'Z')
            || (arr[idx] >= 'a' && arr[idx] <= 'z'))) {
                exit(84);
            }
        if (num == 0 && ((arr[idx] >= 'A' && arr[idx] <= 'Z')
            || (arr[idx] >= 'a' && arr[idx] <= 'z') || arr[idx] == '.')) {
                exit(84);
            }
        idx++;
    }
}

int main(int ac, char **av)
{
    if (av[1] != NULL && av[2] != NULL && av[3] != NULL &&
    av[4] != NULL && av[5] != NULL && av[6] != NULL && av[7] != NULL) {
    confirm_number(av[1], 1);
    confirm_number(av[2], 1);
    confirm_number(av[3], 1);
    confirm_number(av[4], 1);
    confirm_number(av[5], 1);
    confirm_number(av[6], 1);
    confirm_number(av[7], 0);
    }

    if (av[8]) {
        exit(84);
    }
    if (av[7][0] == '-') {
        exit(84);
    } else {
    paddle_conditions(av);
    }
    return 0;
}
