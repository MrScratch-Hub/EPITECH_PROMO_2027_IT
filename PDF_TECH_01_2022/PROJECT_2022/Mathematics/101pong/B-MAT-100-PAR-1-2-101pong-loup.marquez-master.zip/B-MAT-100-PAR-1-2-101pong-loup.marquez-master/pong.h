/*
** EPITECH PROJECT, 2022
** 101pong
** File description:
** 101pong header file
*/

#ifndef PONG_H_
    #define PONG_H_

typedef struct PONG {
double x;
double y;
double z;
} pong;

#endif
