/*
** EPITECH PROJECT, 2020
** 105torus
** File description:
** error_handling
*/

#include "torus.h"

int error_handling_n(char *n)
{
    int idx = 0;
    while (n[idx] != '\0') {
        if (n[idx] < '0' || n[idx] > '9') {
            return (FAIL);
        }
        idx++;
    }
    return (0);
}

int check_error (char **av, int i, int j)
{
    while (av[i][j] != '\0') {
        if ((av[i][j] >= '0' && av[i][j] <= '9') || av[i][j] == '-')
            j++;
        else {
            return (84);
        }
    }
    return (0);
}

int error_handling(int ac, char **av)
{
    int j = 0;
    int idx = 2;
    if (av[1][0] < '1' || av[1][0] > '3') {
        return (FAIL);
    }
    while (idx != ac - 1) {
        j = 0;
        if (check_error(av, idx, j) == 84)
            return 84;
        idx++;
    }
    if (error_handling_n(av[7]) == FAIL)
        return (FAIL);
    return (0);
}
