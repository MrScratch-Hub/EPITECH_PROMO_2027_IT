/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "torus.h"

coef_t *fill_coef(coef_t *c, char **av)
{
    c->a0 = atof(av[2]);
    c->a1 = atof(av[3]);
    c->a2 = atof(av[4]);
    c->a3 = atof(av[5]);
    c->a4 = atof(av[6]);
    return (c);
}

deriv_t *fill_deriv(deriv_t *d, coef_t *c)
{
    d->d0 = c->a1;
    d->d1 = 2 * c->a2;
    d->d2 = 3 * c->a3;
    d->d3 = 4 * c->a4;
    return (d);
}

int check_method(char **av)
{
    int num = atoi(av[1]);
    coef_t *c = malloc(sizeof(double) * 5);
    deriv_t *d = malloc(sizeof(double) * 4);
    int prec = atoi(av[7]) * -1;

    c = fill_coef(c, av);
    d = fill_deriv(d, c);
    if (num == 1)
        bisection_method(c, prec, 0, 1);
    if (num == 2) {
        if (newton_method(c, d, prec, 0.5) == FAIL)
        return (FAIL);
    }
    if (num == 3) {
        if (secant_method(c, prec, 0, 1) == FAIL)
        return (FAIL);
    }
    free(c);
    free(d);
    return (SUCCESS);
}

int main(int ac, char **av)
{
    if (ac != 8) {
        return (FAIL);
    }
    if (error_handling(ac, av) == FAIL)
        return (FAIL);
    if (check_method(av) == FAIL)
        return (FAIL);
    return (SUCCESS);
}
