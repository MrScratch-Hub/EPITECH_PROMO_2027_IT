/*
** EPITECH PROJECT, 2020
** 105torus
** File description:
** compute equations and derived functions
*/

#include  "torus.h"

double compute_derivee(deriv_t *d, double x)
{
    double num = 0;

    num = (d->d3 * pow(x, 3)) + (d->d2 * pow(x, 2));
    num += (d->d1 * x) + d->d0;
    return (num);
}

double compute_equation(coef_t *co, double x)
{
    double num = 0;

    num = (co->a4 * pow(x, 4)) + (co->a3 * pow(x, 3));
    num += (co->a2 * pow(x, 2)) + (co->a1 * x) + co->a0;
    return (num);
}
