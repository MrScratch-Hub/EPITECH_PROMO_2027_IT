/*
** EPITECH PROJECT, 2020
** 105torus
** File description:
** Newton's method
*/

#include "torus.h"

int is_derivable(deriv_t *d, double x)
{
    if (compute_derivee(d, x) == 0) {
        return (FAIL);
    }
    return (SUCCESS);
}

int does_it_stop_newt(double x0, double comp_x, int prec)
{
    double num = x0 - comp_x;

    if (num < 0)
        num = num * -1;
    if (num <= pow(10, prec))
        return (1);
    return (SUCCESS);
}

double compute_newton(coef_t *c, deriv_t *d, double x0)
{
    double num_x = 0;
    double deriv = 0;
    double func = 0;

    func = compute_equation(c, x0);
    deriv = compute_derivee(d, x0);
    num_x = func / deriv;
    num_x = x0 - num_x;
    return (num_x);
}

int newton_method(coef_t *c, deriv_t *d, int prec, double x0)
{
    double x_num = 0;

    int idx = 1;
    while (idx) {
        if (is_derivable(d, x0) == FAIL)
            return (FAIL);
        if (idx == 1)
            printf("x = %.1f\n", x0);
        x_num = x0;
        x0 = compute_newton(c, d, x0);
        if (does_it_stop_newt(x0, x_num, prec) == 1)
            break;
        printf("x = %.*f\n", -prec, x0);
        if (idx == 10000)
            break;
        idx++;
    }
    return (SUCCESS);
}
