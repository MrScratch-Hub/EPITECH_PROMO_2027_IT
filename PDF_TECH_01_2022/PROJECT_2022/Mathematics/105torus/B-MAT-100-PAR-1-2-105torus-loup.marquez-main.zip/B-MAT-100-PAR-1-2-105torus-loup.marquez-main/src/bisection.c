/*
** EPITECH PROJECT, 2020
** 105torus
** File description:
** bisection method
*/

#include "torus.h"

int does_it_stop(double sol, int prec)
{
    if (sol < 0)
        sol = sol * -1;
    else if (sol == 0 || sol <= pow(10, prec))
        return (1);
    return (SUCCESS);
}

float check_a_b_cases(coef_t *co, double a, double b)
{
    double num = 0;

    num = compute_equation(co, a);
    if (num == 0) {
        printf("x = %.0f\n", a);
        return (num);
    }
    num = compute_equation(co, b);
    if (num == 0)
        printf("x = %.0f\n", b);
    return (num);
}

void check_bisection(double sol_a, double sol_c, double *a, double *b)
{
    double c_num = (*a + *b) / 2;
    if (sol_a * sol_c != 0) {
        if (sol_a * sol_c > 0)
            *a = c_num;
        if (sol_a * sol_c < 0)
            *b = c_num;
    }
}

void bisection_computing(coef_t *co, int prec, double a, double b)
{
    int num_p = 1;
    double num_c = 0;
    double num_a = 0;
    int j = 1;
    double c = (a + b) / 2;
    while (num_p != (prec * -1) + 2) {
        if (num_p == (prec * -1) + 1)
            num_p--;
        num_c = compute_equation(co, c);
        printf("x = %.*f\n", num_p, c);
        num_a = compute_equation(co, a);
        if (does_it_stop(num_c, prec) == 1)
            break;
        check_bisection(num_a, num_c, &a, &b);
        if (j == 10000)
            break;
        c = (a + b) / 2;
        j++;
        num_p++;
    }
}

int bisection_method(coef_t *co, int prec, double a, double b)
{
    if (check_a_b_cases(co, a, b) == SUCCESS)
        return (SUCCESS);
    bisection_computing(co, prec, a, b);
    return (SUCCESS);
}
