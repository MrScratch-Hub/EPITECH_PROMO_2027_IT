/*
** EPITECH PROJECT, 2022
** make.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"
pointer *put_pointer(double a, double b, double c)
{
    pointer *ptr = malloc(sizeof(pointer));
    ptr->a = a;
    ptr->b = b;
    ptr->c = c;
    return ptr;
}

member *make_number(char **av)
{
    member *ptr = malloc(sizeof(member));
    int opt = atoi(av[1]);
    double rad = atof(av[8]);
    pointer *point = put_pointer(atof(av[2]), atof(av[3]), atof(av[4]));
    pointer *vector = put_pointer(atof(av[5]), atof(av[6]), atof(av[7]));
    ptr->opt = opt;
    ptr->rad = rad;
    ptr->pnt = point;
    ptr->direct = vector;
    ptr->inter_len = 0;
    return ptr;
}

int make_sphere(member *ptr)
{
    double n1 = pow(ptr->direct->a, 2) + pow(ptr->direct->b, 2)
        + pow(ptr->direct->c, 2);
    double n2 = (2 * ptr->direct->a * ptr->pnt->a) +
        (2 * ptr->direct->b * ptr->pnt->b)
        + (2 * ptr->direct->c * ptr->pnt->c);
    double n3 = pow(ptr->pnt->a, 2) + pow(ptr->pnt->b, 2) +
        pow(ptr->pnt->c, 2) - pow(ptr->rad, 2);
    double del = pow(n2, 2) - 4 * n1 * n3;
    if (n1 == 0) {
        ptr->inter_len = 99;
        ptr->intersect = 0;
        return 0;
    }
    process_formula(ptr, n1, n2, del);
    return 0;
}

int make_cylinder(member *ptr)
{
    double n1 = pow(ptr->direct->a, 2) + pow(ptr->direct->b, 2);
    double n2 = (2 * ptr->pnt->a * ptr->direct->a) + (2 * ptr->pnt->b *
    ptr->direct->b);
    double n3 = pow(ptr->pnt->a, 2) + pow(ptr->pnt->b, 2) - pow(ptr->rad, 2);
    double del = pow(n2, 2) - 4 * n1 * n3;
    if (n1 == 0) {
        ptr->inter_len = 99;
        ptr->intersect = 0;
        return 0;
    }
    process_formula(ptr, n1, n2, del);
    return 0;
}

int make_cone(member *ptr)
{
    double ang = (ptr->rad * M_PI) / 180;
    double n1 = pow(ptr->direct->a, 2) + pow(ptr->direct->b, 2) -
        (pow(ptr->direct->c, 2) * pow(tan(ang), 2));
    double n2 = (2 * ptr->pnt->a * ptr->direct->a) +
        (2 * ptr->pnt->b * ptr->direct->b) -
        ((2 * ptr->pnt->c * ptr->direct->c) * pow(tan(ang), 2));
    double n3 = pow(ptr->pnt->a, 2) + pow(ptr->pnt->b, 2) -
        (pow(ptr->pnt->c, 2) * pow(tan(ang), 2));
    double del = pow(n2, 2) - 4 * n1 * n3;
    if (n1 == 0) {
        ptr->inter_len = 99;
        ptr->intersect = 0;
        return 0;
    }
    process_formula(ptr, n1, n2, del);
    return 0;
}
