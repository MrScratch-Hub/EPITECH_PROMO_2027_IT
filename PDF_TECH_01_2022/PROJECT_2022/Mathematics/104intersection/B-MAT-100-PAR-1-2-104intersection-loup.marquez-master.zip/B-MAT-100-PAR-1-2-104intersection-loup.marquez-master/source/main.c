/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

void confirm_number(char *arr, int num)
{
    int idx = 0;
    while (arr[idx]) {
        if (num == 1 && ((arr[idx] >= 'A' && arr[idx] <= 'Z')
            || (arr[idx] >= 'a' && arr[idx] <= 'z'))) {
            exit(84);
        }
        if (num == 0 && ((arr[idx] >= 'A' && arr[idx] <= 'Z')
            || (arr[idx] >= 'a' && arr[idx] <= 'z') || arr[idx] == '.')) {
            exit(84);
        }
        idx++;
    }
}

int main(int ac, char **av)
{
    if (ac < 9 || ac > 9) {
        return 84;
    }
    if (ac == 9) {
        if (av[1][0] != '1' && av[1][0] != '2' && av[1][0] != '3') {
            exit(84);
        }
        confirm_number(av[1], 1);
        confirm_number(av[2], 1);
        confirm_number(av[3], 1);
        confirm_number(av[4], 1);
        confirm_number(av[5], 1);
        confirm_number(av[6], 1);
        confirm_number(av[7], 1);
        confirm_number(av[8], 1);
        member *ptr;
        ptr = make_number(av);
        if (ptr->opt == 1) {
            make_sphere(ptr);
        } else if (ptr->opt == 2) {
            make_cylinder(ptr);
        } else {
            make_cone(ptr);
        }
        process_print(ptr);
        free(ptr->direct);
        free(ptr->pnt);
        free(ptr->intersect);
        free(ptr);
        exit(0);
    }
}
