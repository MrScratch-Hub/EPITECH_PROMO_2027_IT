/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

void print_opt(member *ptr)
{
    switch (ptr->opt) {
    case 1:
        printf("Sphere of radius %0.f\n", ptr->rad);
        break;
    case 2:
        printf("Cylinder of radius %0.f\n", ptr->rad);
        break;
    default:
        printf("Cone with a %0.f degree angle\n", ptr->rad);
    }
}

void print_pointer(pointer *pnt, int dec)
{
    if (dec == 0)
        printf("(%0.f, %0.f, %0.f)", pnt->a, pnt->b, pnt->c);
    else
        printf("(%0.3f, %0.3f, %0.3f)", pnt->a, pnt->b, pnt->c);
}

void print_intersect(member *ptr)
{
    int idx = 0;
    while (idx < ptr->inter_len) {
        printf("(%.3f, %.3f, %.3f)", ptr->intersect[idx]->a,
        ptr->intersect[idx]->b, ptr->intersect[idx]->c);
        printf("\n");
        idx++;
    }
}
