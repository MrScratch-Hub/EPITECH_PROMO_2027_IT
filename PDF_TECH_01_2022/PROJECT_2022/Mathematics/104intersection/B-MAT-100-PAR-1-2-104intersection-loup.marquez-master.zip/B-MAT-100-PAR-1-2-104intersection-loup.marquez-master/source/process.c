/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

int process_formula(member *ptr, double n1, double n2, double del)
{
    if (del < 0)
        ptr->inter_len = 0;
    else if (del == 0) {
        ptr->inter_len = 1;
        ptr->intersect = malloc(sizeof(pointer) * (ptr->inter_len));
        process_intersect(0, ptr, (-n2 / (2 * n1)));
    } else {
        ptr->inter_len = 2;
        ptr->intersect = malloc(sizeof(pointer) * (ptr->inter_len));
        process_intersect(0, ptr, (-n2 + sqrt(del)) / (2 * n1));
        process_intersect(1, ptr, (-n2 - sqrt(del)) / (2 * n1));
    }
    return 0;
}

int process_intersect(int idx, member *ptr, double n1)
{
    ptr->intersect[idx] = process_pointers(ptr->pnt->a + (n1 * ptr->direct->a),
    ptr->pnt->b + (n1 * ptr->direct->b), ptr->pnt->c + (n1 * ptr->direct->c));
    return 0;
}

pointer *process_pointers(double a, double b, double c)
{
    pointer * pnt = malloc(sizeof(pointer));
    pnt->a = a;
    pnt->b = b;
    pnt->c = c;
    return pnt;
}

void process_print(member *ptr)
{
    print_opt(ptr);
    printf("Line passing through the point ");
    print_pointer(ptr->pnt, 0);
    printf(" and parallel to the vector ");
    print_pointer(ptr->direct, 0);
    printf("\n");
    if (ptr->inter_len == 0)
        printf("No intersection point.\n");
    else if (ptr->inter_len >= 99) {
        printf("There is an infinite number of intersection points.\n");
        return;
    }
    else if (ptr->inter_len == 1)
        printf("1 intersection point:\n");
    else if (ptr->inter_len == 2)
        printf("2 intersection points:\n");
    print_intersect(ptr);
}
