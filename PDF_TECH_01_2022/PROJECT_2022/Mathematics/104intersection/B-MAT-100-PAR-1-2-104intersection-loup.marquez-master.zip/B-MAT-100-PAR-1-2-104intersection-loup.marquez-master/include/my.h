/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#ifndef MY_H_
    #define MY_H_
    #include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <string.h>
    #include <math.h>

typedef struct pointers {
    double a;
    double b;
    double c;
} pointer;

typedef struct members {
    int opt;
    struct pointers *pnt;
    struct pointers *direct;
    struct pointers **intersect;
    int inter_len;
    double rad;
} member;

member *make_number(char **av);
pointer *put_pointer(double a, double b, double c);
int make_sphere(member *ptr);
int make_cylinder(member *ptr);
int make_cone(member *ptr);
int process_formula(member *ptr, double n1, double n2, double del);
int process_intersect(int idx, member *ptr, double n1);
pointer *process_pointers(double a, double b, double c);
void process_print(member *ptr);
void print_opt(member *ptr);
void print_pointer(pointer *pnt, int dec);
void print_intersect(member *ptr);
#endif
