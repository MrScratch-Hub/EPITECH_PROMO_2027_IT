/*
** EPITECH PROJECT, 2023
** B-MAT-200-PAR-2-2-106bombyx-loup.marquez
** File description:
** main
*/

#include <iostream>
#include <iomanip>
#include <string>

void print_usage() {
  std::cout << "USAGE" << std::endl;
  std::cout << "\t./106bombyx n [k | i0 i1]" << std::endl;
  std::cout << std::endl;
  std::cout << "DESCRIPTION" << std::endl;
  std::cout << "\tn\tnumber of first generation individuals" << std::endl;
  std::cout << "\tk\tgrowth rate from 1 to 4" << std::endl;
  std::cout << "\ti0\tinitial generation (included)" << std::endl;
  std::cout << "\ti1\tfinal generation (included)" << std::endl;
}

void cal_bombyx(double n, double k, int i) {
  double x = n;
  for (int j = 1; j <= i; j++) {
    std::cout << j << " " << std::fixed << std::setprecision(2) << x << std::endl;
    x = k * x * (1000 - x) / 1000;
  }
}

void cal_synthetic(char **av) {
  double n = atof(av[1]);
  int i0 = atoi(av[2]);
  int i1 = atoi(av[3]);
  double res = n;
  double k = 1.0;
  int i = 1;
  while (k <= 4.0) {
    while (i < i0) {
      n = k * n * (1000 - n) / 1000;
      i++;
      if (n < 0) {
        n = 0;
      }
    }
    while (i <= i1) {
      printf("%.2f %.2f\n", k, n);
      n = k * n * (1000 - n) / 1000;
      i++;
      if (n < 0) {
        n = 0;
      }
    }
    k += 0.01;
    i = 1;
    n = res;
  }
}

int main(int ac, char **av) {
  if (ac < 2) {
    std::cout << "invalide arguments" << std::endl;;
    exit(84);
  }
  if (ac == 2 && std::string(av[1]) == "-h") {
    print_usage();
    return 0;
  } try {
    double n = std::stod(av[1]);
    if (ac == 3) {
      double k = std::stod(av[2]);
      if (k > 4) {
        std::cout << "growth rate from 1 to 4" << std::endl;;
        exit(84);
      }
      cal_bombyx(n, k, 100);
    } else if (ac == 4) {
      cal_synthetic(av);
    } else {
      throw std::invalid_argument("Invalid arguments");
      exit(84);
    }
  }
    catch (const std::exception& e) {
    std::cerr << e.what() << std::endl;
    return 84;
  }

  return 0;
}
