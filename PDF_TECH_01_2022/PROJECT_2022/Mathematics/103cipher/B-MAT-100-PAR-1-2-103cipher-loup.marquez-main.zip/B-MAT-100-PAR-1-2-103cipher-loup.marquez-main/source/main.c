/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

void rigor_handling(int ac, char **av)
{
    if (ac == 1 || ac == 2 || ac == 3) {
        exit(84);
    }
    if (ac >= 5) {
        exit(84);
    }
}

ciper * make_ciper(ciper *ptr)
{
    make_key_master(ptr);
    if (ptr->flag == 1) {
        exit(0);
    }
    if (ptr->flag == 0) {
        make_message(ptr);
    }
    ptr->array = malloc(sizeof(int) * ptr->message_size);
    complete_ciper(ptr);
    show_ciper(ptr);
    return ptr;
}

int main(int ac, char **av)
{
    rigor_handling(ac, av);
    if (ac == 4 ) {
        ciper *ptr = put_ciper(av[1], av[2], av[3]);
        ptr = make_ciper(ptr);
        free(ptr->array);
        free(ptr->message_master);
        free(ptr->key_master);
        free(ptr);
        exit(0);
    } else {
        exit(84);
    }
    return 0;
}
