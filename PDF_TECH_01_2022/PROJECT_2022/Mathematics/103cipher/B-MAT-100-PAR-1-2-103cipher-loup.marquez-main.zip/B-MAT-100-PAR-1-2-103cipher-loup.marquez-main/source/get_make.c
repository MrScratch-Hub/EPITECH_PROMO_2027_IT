/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

int get_ciper_size(ciper *ptr)
{
    int len;
    if (ptr->key_size == 4) {
        len = 2;
    }
    if (ptr->key_size == 9) {
        len = 3;
    }
    return len;
}

int make_key_size(char *key)
{
    int size = strlen(key);
    if (size <= 4)
        return 4;
    if (size <= 9)
        return 9;
    else
        return 4;
}

int make_message_size(char *message, int key_size)
{
    int message_len = strlen(message);
    int size;
    if (key_size == 4) {
        size = 2;
    }
    if (key_size == 9) {
        size = 3;
    }
    while (message_len % size == 0) {
        message_len++;
    }
    return message_len;
}

void make_key_master(ciper *ptr)
{
    int idx = 0;
    int cnt = make_key_size(ptr->key);
    int cnt_input = strlen(ptr->key);
    ptr->key_master = malloc(sizeof(int) * cnt);
    while (idx < cnt) {
        if (idx >= cnt_input) {
            ptr->key_master[idx] = 0;
        } else {
            ptr->key_master[idx] = ptr->key[idx];
        }
        idx++;
    }
}

void make_message(ciper *ptr)
{
    int idx = 0;
    int cnt = strlen(ptr->message);
    int cnt_input = strlen(ptr->message);
    cnt = make_message_size(ptr->message, cnt);
    ptr->message_master = malloc(sizeof(int) * cnt);
    while (idx < cnt) {
        if (idx >= cnt_input) {
            ptr->message_master[idx] = 0;
        } else {
            ptr->message_master[idx] = ptr->message[idx];
        }
        idx++;
    }
}
