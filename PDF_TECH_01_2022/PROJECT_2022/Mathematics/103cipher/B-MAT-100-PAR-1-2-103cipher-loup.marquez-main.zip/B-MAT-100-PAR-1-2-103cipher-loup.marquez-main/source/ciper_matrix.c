/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

ciper *put_ciper(char *message, char *key, char *flag)
{
    ciper * ptr = malloc(sizeof(ciper));
    ptr->key = key;
    ptr->key_size = make_key_size(key);
    ptr->message = message;
    ptr->message_size = make_message_size(message, ptr->key_size);
    if (flag[0] == '1') {
        ptr->flag = 1;
    } else if (flag[0] == '0') {
        ptr->flag = 0;
    } else {
        exit(84);
    }
    return ptr;
}

void matrix_2(ciper *ptr, int n0, int n1)
{
    ptr->array[n1 - 1] = (ptr->message_master[n0] * ptr->key_master[0]) +
        (ptr->message_master[n1] * ptr->key_master[2]);
    ptr->array[n1] = (ptr->message_master[n0] * ptr->key_master[1]) +
        (ptr->message_master[n1] * ptr->key_master[3]);
}

void matrix_3(ciper *ptr, int n0, int n1, int n2)
{
    ptr->array[n2 - 2] = (ptr->message_master[n0] * ptr->key_master[0]) +
        (ptr->message_master[n1] * ptr->key_master[3]) +
        (ptr->message_master[n2] * ptr->key_master[6]);
    ptr->array[n2 - 1] = (ptr->message_master[n0] * ptr->key_master[1]) +
        (ptr->message_master[n1] * ptr->key_master[4]) +
        (ptr->message_master[n2] * ptr->key_master[7]);
    ptr->array[n2] = (ptr->message_master[n0] * ptr->key_master[2]) +
        (ptr->message_master[n1] * ptr->key_master[5]) +
        (ptr->message_master[n2] * ptr->key_master[8]);
}

void complete_ciper(ciper *ptr)
{
    int n0 = 0;
    int n1 = 1;
    int n2 = 2;
    int len = get_ciper_size(ptr);
    int idx = len - 1;
    while (idx < ptr->message_size) {
        if (len == 2)
            matrix_2(ptr, n0, n1);
        if (len == 3)
            matrix_3(ptr, n0, n1, n2);
        idx += len;
        n0 = n0 + len;
        n1 = n1 + len;
        n2 = n2 + len;
    }
}
