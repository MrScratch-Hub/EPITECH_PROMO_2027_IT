/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

void show_ciper_key(int *ptr, int len)
{
    int idx;
    int cnt;
    if (len <= 4)
        cnt = 2;
    if (len <= 9)
        cnt = 3;
    for (idx = 0; idx < len; idx++) {
        if ((idx + 1) % cnt == 0) {
            printf("%d", ptr[idx]);
            printf("\n");
        } else {
            printf("%-9d", ptr[idx]);
        }
    }
}

void show_ciper_message(int *array, int len)
{
    int idx = 0;
    while (idx < len) {
        if (array[idx] != 0)
            printf("%d", array[idx]);
        if (array[idx + 1] != 0)
            printf(" ");
        idx++;
    }
    printf("\n");
}

void show_ciper(ciper *ptr)
{
    printf("Key matrix:\n");
    if (ptr->flag == 0) {
        show_ciper_key(ptr->key_master, ptr->key_size);
        printf("\nEncrypted message:\n");
        show_ciper_message(ptr->array, ptr->message_size);
    }
}
