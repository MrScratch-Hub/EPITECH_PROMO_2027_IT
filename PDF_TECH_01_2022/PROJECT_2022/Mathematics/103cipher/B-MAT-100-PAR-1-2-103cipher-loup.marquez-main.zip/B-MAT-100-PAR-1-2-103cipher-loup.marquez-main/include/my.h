/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#ifndef _MY_H_
    #define _MY_H_

    #include <stdio.h>
    #include <stdlib.h>
    #include <string.h>

typedef struct CIPER {
    char *key;
    char *message;
    int *key_master;
    int *message_master;
    int *array;
    int flag;
    int key_size;
    int message_size;
} ciper;

ciper *put_ciper(char *message, char *key, char *flag);
void matrix_2(ciper *ptr, int n0, int n1);
void matrix_3(ciper *ptr, int n0, int n1, int n2);
void complete_ciper(ciper *ptr);
void show_ciper_key(int *ptr, int len);
void show_ciper_message(int *array, int len);
void show_ciper(ciper *ptr);
int get_ciper_size(ciper *ptr);
int make_key_size(char *key);
int make_message_size(char *message, int key_size);
void make_key_master(ciper *ptr);
void make_message(ciper *ptr);
ciper *make_ciper(ciper *ptr);
int main(int ac, char **av);

#endif
