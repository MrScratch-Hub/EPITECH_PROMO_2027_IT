/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

void print_angle_or_rotation(char **av, double arr[], table *p)
{

    if (av[3][1] == 'r') {
        printf("Rotation by a %0.f degree angle\n", atof(av[4]));
        make_rotation_table(arr, av, p);
    }
    if (av[3][1] == 's') {
        printf("Reflection over an axis with an inclination angle of");
        printf(" %0.f degrees\n", atof(av[4]));
        make_angle_table(arr, av, p);
    }
}

void print_vector_or_scale(char **av, double arr[], table *p)
{
    if (av[3][1] == 't') {
        printf("Translation along vector");
        printf(" (%0.f, %0.f)\n", atof(av[4]), atof(av[5]));
        make_vector_table(arr, av, p);
    }
    if (av[3][1] == 'z') {
        printf("Scaling by factors %0.f and %0.f\n", atof(av[4]), atof(av[5]));
        make_scale_table(arr, av, p);
    }
}

void put_matrix(double ptr[], table *p, table *x_y)
{
    double ptr2[9];
    double ptr3[2];
    int i;
    for (i = 0; i < 9; i++) {
        ptr2[i] = ptr[i];
    }
    ptr3[0] = (ptr[0] * x_y->a) + (ptr[1] * x_y->b) + (ptr[2] * 1);
    ptr3[1] = (ptr[3] * x_y->a) + (ptr[4] * x_y->b) + (ptr[5]);
    p->a = ptr3[0];
    p->b = ptr3[1];
}

void print_matrix(double *ptr)
{
    int i;
    for (i = 0; i < 9; i++) {

        if ((i + 1) % 3 == 0) {
            printf("%0.2f", ptr[i]);
            printf("\n");
        } else {
            printf("%-9.2f", ptr[i]);
        }
    }
}

void print_result(table *p, table *x_y)
{
    printf("(%0.2f, %0.2f) => (%0.2f, %0.2f)\n", x_y->a, x_y->b, p->a, p->b);
}
