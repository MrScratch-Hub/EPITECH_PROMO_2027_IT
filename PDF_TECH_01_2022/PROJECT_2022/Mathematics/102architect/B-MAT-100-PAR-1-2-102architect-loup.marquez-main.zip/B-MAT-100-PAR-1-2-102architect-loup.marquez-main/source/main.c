/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include "../include/my.h"

void confirm_number(char *arr, int num)
{
    int idx = 0;
    while (arr[idx]) {
        if (num == 1 && ((arr[idx] >= 'A' && arr[idx] <= 'Z')
            || (arr[idx] >= 'a' && arr[idx] <= 'z'))) {
                exit(84);
            }
        if (num == 0 && ((arr[idx] >= 'A' && arr[idx] <= 'Z')
            || (arr[idx] >= 'a' && arr[idx] <= 'z') || arr[idx] == '.')) {
                exit(84);
            }
        idx++;
    }
}

void argument1(int ac, char **av, double arr[], table *p)
{
    if (av[1] != NULL && av[2] != NULL && av[3][0] == '-' && av[3][1] == 't'
    && av[4] != NULL && av[5] != NULL && ac == 6 ||
    av[1] != NULL && av[2] != NULL && av[3][0] == '-' && av[3][1] == 'z'
    && av[4] != NULL && av[5] != NULL && ac == 6) {
        confirm_number(av[1], 1);
        confirm_number(av[2], 1);
        confirm_number(av[4], 1);
        confirm_number(av[5], 1);
        print_vector_or_scale(av, arr, p);
        exit(0);
    }
}

void argument2(int ac, char **av, double arr[], table *p)
{
    if (av[1] != NULL && av[2] != NULL && av[3][0] == '-' && av[3][1] == 'r'
    && av[4] != NULL && ac == 5
    || av[1] != NULL && av[2] != NULL && av[3][0] == '-' && av[3][1] == 's'
    && av[4] != NULL && ac == 5) {
        confirm_number(av[1], 1);
        confirm_number(av[2], 1);
        confirm_number(av[4], 1);
        print_angle_or_rotation(av, arr, p);
        exit(0);
    } else {
        exit(84);
    }
}

int main(int ac, char **av)
{
    table * p = malloc(sizeof(table));
    double arr[] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
    if (ac <= 3) {
        exit(84);
    }
    argument1(ac, av, arr, p);
    argument2(ac, av, arr, p);
    free(p);
    return 0;
}
