/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

void make_rotation_table(double arr[], char **av, table *p)
{
    table * x_y = malloc(sizeof(table));
    double * ptr;
    double degree = atof(av[4]);
    degree = (degree * M_PI) / 180;
    double i = cos(degree);
    double j = sin(degree);
    p->a = i;
    p->b = j;
    x_y->a = atof(av[1]);
    x_y->b = atof(av[2]);
    ptr = make_matrix_rotation(arr, p, x_y);
    put_matrix(ptr, p, x_y);
    print_matrix(ptr);
    print_result(p, x_y);
    free(ptr);
}

void make_angle_table(double arr[], char **av, table *p)
{
    table * x_y = malloc(sizeof(table));
    double * ptr;
    double degree = atof(av[4]);
    degree = (degree * M_PI) / 180;
    double i = cos(2 * degree);
    double j = sin(2 * degree);
    p->a = i;
    p->b = j;
    x_y->a = atof(av[1]);
    x_y->b = atof(av[2]);
    ptr = make_matrix_angle(arr, p, x_y);
    put_matrix(ptr, p, x_y);
    print_matrix(ptr);
    print_result(p, x_y);
    free(ptr);
}

double *make_matrix_rotation(double arr[], table *p, table *x_y)
{
    int i;
    double *ptr = malloc(sizeof(double)*9);
    for (i = 0; i < 9; i++) {
        ptr[i] = arr[i];
    }
    ptr[0] = p->a;
    ptr[4] = p->a;
    ptr[1] = -(p->b);
    ptr[3] = p->b;
    ptr[8] = 1;
    ptr[2] = arr[2];
    ptr[5] = arr[5];
    ptr[6] = arr[6];
    ptr[7] = arr[7];
    return ptr;
}

double *make_matrix_angle(double arr[], table *p, table *x_y)
{
    int i;
    double *ptr = malloc(sizeof(double)*9);
    ptr[1] = p->b;
    ptr[3] = p->b;
    ptr[0] = p->a;
    ptr[4] = -(p->a);
    ptr[2] = arr[2];
    ptr[5] = arr[5];
    ptr[6] = arr[6];
    ptr[7] = arr[7];
    ptr[8] = arr[8];
    return ptr;
}
