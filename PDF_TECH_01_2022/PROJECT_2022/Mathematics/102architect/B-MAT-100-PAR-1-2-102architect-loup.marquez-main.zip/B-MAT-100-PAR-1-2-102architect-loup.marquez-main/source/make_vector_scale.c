/*
** EPITECH PROJECT, 2022
** main.c
** File description:
** No file there, just an epitech header example.
*/

#include "../include/my.h"

void make_vector_table(double arr[], char **av, table *p)
{
    table * x_y = malloc(sizeof(table));
    double * ptr;
    double i = atof(av[4]);
    double j = atof(av[5]);
    p->a = i;
    p->b = j;
    x_y->a = atof(av[1]);
    x_y->b = atof(av[2]);
    ptr = make_matrix_vector(arr, p, x_y);
    put_matrix(ptr, p, x_y);
    print_matrix(ptr);
    print_result(p, x_y);
    free(ptr);
}

void make_scale_table(double arr[], char **av, table *p)
{
    table * x_y = malloc(sizeof(table));
    double * ptr;
    double i = atof(av[4]);
    double j = atof(av[5]);
    p->a = i;
    p->b = j;
    x_y->a = atof(av[1]);
    x_y->b = atof(av[2]);
    ptr = make_matrix_scale(arr, p, x_y);
    put_matrix(ptr, p, x_y);
    print_matrix(ptr);
    print_result(p, x_y);
    free(ptr);

}

double *make_matrix_vector(double arr[], table *p, table *x_y)
{
    int i;
    double *ptr = malloc(sizeof(double)*9);
    for (i = 0; i < 9; i++) {
        ptr[i] = arr[i];
    }
    ptr[2] = p->a;
    ptr[5] = p->b;
    return ptr;
}

double *make_matrix_scale(double arr[], table *p, table *x_y)
{
    int i;
    double *ptr = malloc(sizeof(double)*9);
    for (i = 0; i < 9; i++) {
        ptr[i] = arr[i];
    }
    ptr[0] = p->a;
    ptr[4] = p->b;
    return ptr;
}
