/*
** EPITECH PROJECT, 2022
** my.h
** File description:
** No file there, just an epitech header example.
*/

#ifndef __MY_H__
    #define __MY_H__

    #include <stdio.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <math.h>

typedef struct _table {
    double a;
    double b;
} table;

void put_matrix(double ptr[], table *p, table *x_y);
double *make_matrix_rotation(double arr[], table *p, table *x_y);
double *make_matrix_angle(double arr[], table *p, table *x_y);
void print_matrix(double *ptr);
void print_result(table *p, table *x_y);
void make_rotation_table(double arr[], char **av, table *p);
void make_angle_table(double arr[], char **av, table *p);
void print_angle_or_rotation(char **av, double arr[], table *p);
int check_angle_and_rotation(int ac, char **av);
int check_vector_and_scale(int ac, char **av);
void make_vector_table(double arr[], char **av, table *p);
void make_scale_table(double arr[], char **av, table *p);
double *make_matrix_vector(double arr[], table *p, table *x_y);
double *make_matrix_scale(double arr[], table *p, table *x_y);
void print_vector_or_scale(char **av, double arr[], table *p);

#endif
